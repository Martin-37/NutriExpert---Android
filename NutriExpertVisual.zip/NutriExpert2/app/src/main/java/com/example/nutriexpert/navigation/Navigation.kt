package com.example.nutriexpert.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.nutriexpert.ui.views.HistorialScreen
import com.example.nutriexpert.ui.views.RecoleccionScreen
import com.example.nutriexpert.ui.views.ValidacionDosisScreen

import com.example.nutriexpert.data.AppState

@Composable
fun AppNavigation(navController: NavHostController, appState: AppState){
    NavHost(
        navController = navController, startDestination = "recoleccion"
    ) {
        composable("recoleccion") { RecoleccionScreen(navController, appState) }
        composable("historialSincronizacion") { HistorialScreen(navController, appState) }
        composable("validacionRecomendacion") { ValidacionDosisScreen(navController, appState) }
    }
}