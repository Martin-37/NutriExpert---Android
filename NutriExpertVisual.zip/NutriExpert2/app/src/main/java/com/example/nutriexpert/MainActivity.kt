package com.example.nutriexpert

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import com.example.nutriexpert.ui.theme.NutriExpertTheme
import androidx.navigation.compose.rememberNavController
import com.example.nutriexpert.data.AppState
import com.example.nutriexpert.navigation.AppNavigation

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appState = AppState()

        setContent {
            NutriExpertTheme {
                MyApp(appState)
            }
        }
    }
}

@Composable
fun MyApp(appState: AppState) {
    val navController = rememberNavController()
    MaterialTheme {
        AppNavigation(navController, appState)
    }
}