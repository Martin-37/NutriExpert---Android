package com.example.nutriexpert.data

class AppState {
}